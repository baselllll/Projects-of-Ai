package agentapplication;

import jade.core.*;
import jade.lang.acl.ACLMessage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Agent1 extends Agent{
    
    protected void setup(){
        try {
            String Agent1;
            //System.out.println("AID"+getAID().getLocalName());
            // System.out.println("GUID"+getAID().getName());
            //ACLMessage acl = new ACLMessage(ACLMessage.REQUEST);
            //acl.addReceiver(new AID("Agent2",AID.ISLOCALNAME));
            // acl.setContent("info");
            //this.send(acl);
            //this.addBehaviour(new Behave("helllo I am Agent 1"));
           for(int i=0;i<=30;i++){
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
            Statement st=con.createStatement();
            ResultSet re=st.executeQuery("SELECT * FROM Checker ");
            Scanner input=new Scanner(System.in);
           System.out.print("Agent 1:");
             Agent1=input.nextLine();
             while(re.next()){
             if(Agent1.equals(re.getString(1))){
                 System.out.println("Agent 2:"+re.getString(2));
             }
             }
           }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Agent1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Agent1.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
    protected void takeDown(){
        System.out.println("destroyed");
    }
    
}
