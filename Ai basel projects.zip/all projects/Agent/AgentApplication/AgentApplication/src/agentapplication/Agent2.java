package agentapplication;
import jade.core.Agent;
public class Agent2 extends Agent{
  
    protected void setup(){
       // this.addBehaviour(new Behave2("helllo I am Agent 2"));
        
    }}
