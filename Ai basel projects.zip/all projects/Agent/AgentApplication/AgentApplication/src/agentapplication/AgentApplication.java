package agentapplication;

public class AgentApplication {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
