package agentapplication;

import jade.core.behaviours.Behaviour;
import jade.imtp.leap.JICP.Connection;
import java.beans.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Behave extends Behaviour{

    public Behave(String msg) {
        System.out.println(msg);
    }

    @Override
    public void action() {
          
    }

    @Override
    public boolean done() {
        return true;
        }
    
}
