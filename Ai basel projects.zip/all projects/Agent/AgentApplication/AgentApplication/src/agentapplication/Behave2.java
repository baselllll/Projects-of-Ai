package agentapplication;

import jade.core.behaviours.Behaviour;
import jade.imtp.leap.JICP.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Behave2 extends Behaviour{

    public Behave2(String msg) {
        System.out.println(msg);
    }

    @Override
    public void action() {
       
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Behave2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Behave2.class.getName()).log(Level.SEVERE, null, ex);
        }
           
        }

    @Override
    public boolean done() {
        return true;
        }
    
}
