package agentapplication;
import jade.core.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Agent1 extends Agent{
    
    protected void setup(){
        try {
            for(int i=1;i<=30;i++){
            String Agent1,Agent2;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
            Statement st=con.createStatement();
            Statement st2=con.createStatement();
            ResultSet re=st.executeQuery("SELECT * FROM Checker ");
             ResultSet re2=st2.executeQuery("SELECT * FROM Checker ");
            Scanner input=new Scanner(System.in);
           System.out.print("Agent 1:");
             Agent1=input.nextLine();
             while(re.next()){
                 
             if(Agent1.equals(re.getString(1))){
                 System.out.println("Agent 2:"+re.getString(4));
             }       
             }
             System.out.print("Agent 2:");
             Agent2=input.nextLine();
             while(re2.next()){ 
             if(Agent2.equals(re2.getString(3))){
              System.out.println("Agent 1:"+re2.getString(2));           
             }
             }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Agent1.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    @Override
    protected void takeDown(){
        System.out.println("destroyed");
    }
    
}
