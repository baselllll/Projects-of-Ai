package neural;
public class Neural {
    double new_weight;
    double classification;
    public String Sum_Of_Product
        (double x0,double x1,double x2,double x3,double w0,double w1,double w2,double w3,double desired_output,double learning_rate_m){
        double SGN_sum;
        SGN_sum=x0*w0+x1*w1+x2*w2+x3*w3;
                
        if(SGN_sum>=1){
            double ww1=0,ww2=0,ww3=0,ww4=0;
            System.out.println("Sum OF Product= "+SGN_sum);//SG_sum=predicated
            double SG_sum=1;
            System.out.println("predicted_output ="+SG_sum);
            System.out.println("W(n+1)=W(n)+learning_rate[d(n)-y(n)] x(n)");
            double []w_n={w0,w1,w2,w3};
            double []x_n={x0,x1,x2,x3};
            double output=desired_output-SG_sum;
            double part2=learning_rate_m * output;
            for(int i=0;i<=3;i++){
                  new_weight=w_n[i]+ part2*x_n[i];
                 System.out.println("new weight x"+i+" = "+new_weight);
                 if(i==0){
                     ww1=new_weight;
                 }
                 if(i==1){
                     ww2=new_weight;
                 }
                 if(i==2){
                     ww3=new_weight;
                 }
                 if(i==3){
                     ww4=new_weight;
                 }
            }
         Sum_Of_Product(1,0, 0, 255,ww1,ww2,ww3,ww4,1,.001);   
        }
        else if(SGN_sum<1){
            System.out.println("Sum OF Product= "+SGN_sum);
           double SG_sum=-1;
         System.out.println("predicted_output ="+SG_sum);
         double []w_n={w0,w1,w2,w3};
            double []x_n={x0,x1,x2,x3};
            double output=desired_output-SG_sum;
            double part2=learning_rate_m * output;
            for(int i=0;i<=3;i++){
                  new_weight=w_n[i]+ part2*x_n[i];
                 System.out.println("new weight x"+i+" = "+new_weight);
                 
            }
           
        }
    return "";
    }
    public static void main(String[] args) {
       Neural nw=new Neural();
               System.out.println("X(n)=[x0,x1,x2,x3,w0,w1,w2,w3,Desired_Output,Learning_rate]");
               System.out.println("---------------------------------First Sample------------------------------------------");
               System.out.println(nw.Sum_Of_Product(1,255,0,0,-1,-2,1,6.2,-1,.001));
                System.out.println("---------------------------Second Sample------------------------------------------------");
               System.out.println(nw.Sum_Of_Product(1,248, 80,68,-1, -2,1,6.2,-1,.001));

 System.out.println("----------------------------Thired sample with new weight-----------------------------------------------");
               System.out.println(nw.Sum_Of_Product(1,0, 0, 255,-1.002, -2.496, .84,6.064,1,.001));
               System.out.println("----------------------------Any sample with new weight-----------------------------------------------");
               System.out.println(nw.Sum_Of_Product(1,484,100,700,-1.002, -2.496, .84,6.064,1,.001));
    }
    
}