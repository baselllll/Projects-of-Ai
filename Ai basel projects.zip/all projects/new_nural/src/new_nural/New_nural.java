package new_nural;
import java.util.Arrays;
import java.util.Scanner;

public class New_nural {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter x1 : ");
        double x1 = input.nextDouble();
        System.out.println("Enter x2 : ");
        double x2 = input.nextDouble();
        int x0 = +1;
        double x []= {x0,x1,x2};
        
        System.out.println("Enter b : ");
        double b = input.nextDouble();
        System.out.println("Enter w1 : ");
        double w1 = input.nextDouble();
        System.out.println("Enter w2 : ");
        double w2 = input.nextDouble();
        double w []={b,w1,w2};
        
        System.out.println("Enter M(Learning rate) : ");
        double m = input.nextDouble();
        
        System.out.println("Enter Desired output : ");
        double d = input.nextDouble();
        
        int sgnClass1 = +1; 
        int sgnClass2 = -1;
        
        for (int i = 0; i <= 1000; i++ ){
           double Y = 0; 
          for( int n=0; n<3; n++)
               Y += x[n] * w[n];//sum of product
        
        if (Y > 0) {  // 0 threshold //Activation function
            Y = +1;
        } else{
            Y = -1;
        }
        
        System.out.println( "Actual output is : "+Y +"   Desired output is : "+d);
            System.out.println("Weights : "+ Arrays.toString(w));
        
        if (d == Y ) {//disired==Actual
            System.out.println("done ");
            if (Y == sgnClass1) {
                System.out.println("This belongs to Class 1 ;");
            } else {
                System.out.println("This belongs to Class 2 ;");
            }
            break;       
        } else{
            for(int k =0; k < 3; k++){
             w[k] = w[k] + ((m *(d - Y)) * x[k]);//weight adaption
            }
            System.out.println("New Weights : " +Arrays.toString(w));
        }
        
        }
    }
}