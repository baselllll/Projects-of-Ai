chatting('hello my friend','hello my best friend').
chatting('what is your name?','my name is Ali').
chatting('my name is ahmed','what is your name also?').
chatting('what is your age Ali?','my age is 20 year').
chatting('my age is 23 year','what is your age ahmed?').
chatting('do you single or married?','single').
chatting('single also','do you single or married?').
chatting('what do you want to be Ali?','i hope to be engineer').
chatting('I hope to be doctor','what do you want to be ahmed?').
