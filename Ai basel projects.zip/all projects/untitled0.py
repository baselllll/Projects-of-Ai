# -*- coding: utf-8 -*-
"""
Created on Mon May 14 08:55:28 2018

@author: Bessso
"""
import numpy  

 def activation_function(inpt):  
      if(inpt > 250):  
         return 250 # clip the result to 250  
      else:  
          return inpt # just return the input  
          
  def prediction_error(desired, expected):  
     return numpy.abs(numpy.mean(desired-expected)) # absolute error  
   
 def update_weights(weights, predicted, idx):  
     weights = weights + .00001*(desired_output[idx] - predicted)*inputs[idx] # updating weights  
     return weights # new updated weights  
   
 weights = numpy.array([0.05, .1]) #bias & weight of input  
 inputs = numpy.array([60, 40, 100, 300, -50, 310]) # training inputs  
 desired_output = numpy.array([60, 40, 150, 250, -50, 250]) # training outputs  
   
 def training_loop(inpt, weights):  
     error = 1  
     idx = 0 # start by the first training sample  
     iteration = 0 #loop iteration variable  
     while(iteration < 2000 or error >= 0.01): #while(error >= 0.1):  
         predicted = activation_function(weights[0]*1+weights[1]*inputs[idx])  
         error = prediction_error(desired_output[idx], predicted)  
         weights = update_weights(weights, predicted, idx)  
         idx = idx + 1 # go to the next sample  
         idx = idx % inputs.shape[0] # restricts the index to the range of our samples  
         iteration = iteration + 1 # next iteration  
     return error, weights  
   
 error, new_weights = training_loop(inputs, weights)  
 print('--------------Final Results----------------')  
 print('Learned Weights : ', new_weights)  
 new_inputs = numpy.array([10, 240, 550, -160])  
 new_outputs = numpy.array([10, 240, 250, -160])  
 for i in range(new_inputs.shape[0]):  
     print('Sample ', i+1, '. Expected = ', new_outputs[i], ' , 
          Predicted = ', activation_function(new_weights[0]*1+new_weights[1]*new_inputs[i]))  